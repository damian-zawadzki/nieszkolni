function showHide() {
  var file = document.getElementById("file_upload");
  if (file.style.display === "none") {
    file.style.display = "block";
  } else {
    file.style.display = "none";
  }
}